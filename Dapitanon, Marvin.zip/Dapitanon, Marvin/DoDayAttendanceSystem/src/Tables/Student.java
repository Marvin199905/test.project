/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Tables;

import DBConnection.DBConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class Student {

    private int id;
    private String Firstname;
    private String Lastname;
    private String Course;
    private String InstituteName;
    private String Date;

    public Student() {
    }

    public void select() {
        try {
            Vector row = new Vector();
            row.setSize(0);

            DBConnection.databaseConnection();

            PreparedStatement preparedStatement = DBConnection.connection.prepareStatement("select select id,Firstname,Lastname,Course,InstituteName,date from student;");
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                String idl = resultSet.getString("id");
                String Firstname = resultSet.getString("Firstname");
                String Lastname = resultSet.getString("Lastname");
                String Course = resultSet.getString("Course");
                String InstituteName = resultSet.getString("InstituteName");
                String Date = resultSet.getString("Date");

                Vector column = new Vector();
                column.add(idl);
                column.add(Firstname);
                column.add(Lastname);
                column.add(Course);
                column.add(InstituteName);
                column.add(Date);
                row.add(column);
            }
            resultSet.close();
            preparedStatement.close();

            for (int i = 0; i < row.size(); i++) {
                System.out.println(row.get(i));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void insert() {
        try {
            DBConnection.databaseConnection();

            PreparedStatement preparedStatement = DBConnection.connection.prepareStatement("insert into student(select id,Firstname,Lastname,Course,InstituteName,date) values (?,?,?,?,?,?)");
            preparedStatement.setInt(1, getId());
            preparedStatement.setString(2, getFirstname());
            preparedStatement.setString(3, getLastname());
            preparedStatement.setString(4, getCourse());
            preparedStatement.setString(5, getInstituteName());
            preparedStatement.setString(6, getDate());

            preparedStatement.execute();

            preparedStatement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void update() {
        try {
            DBConnection.databaseConnection();
            PreparedStatement preparedStatement = DBConnection.connection.prepareStatement("update student set select Firstname=?,Lastname=?,Course=?,InstituteName=?,date=? where id = ?");

            preparedStatement.setString(1, getFirstname());
            preparedStatement.setString(2, getLastname());
            preparedStatement.setString(3, getCourse());
            preparedStatement.setString(4, getInstituteName());
            preparedStatement.setString(5, getDate());
            preparedStatement.setInt(6, getId());
            preparedStatement.execute();
            preparedStatement.close();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void delete() {
        try {
            DBConnection.databaseConnection();
            PreparedStatement statement = DBConnection.connection.prepareStatement("delete from  student"
                    + "where id = ?");
            statement.setInt(1, getId());
            statement.execute();
            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the Firstname
     */
    public String getFirstname() {
        return Firstname;
    }

    /**
     * @param Firstname the Firstname to set
     */
    public void setFirstname(String Firstname) {
        this.Firstname = Firstname;
    }

    /**
     * @return the Lastname
     */
    public String getLastname() {
        return Lastname;
    }

    /**
     * @param Lastname the Lastname to set
     */
    public void setLastname(String Lastname) {
        this.Lastname = Lastname;
    }

    /**
     * @return the Course
     */
    public String getCourse() {
        return Course;
    }

    /**
     * @param Course the Course to set
     */
    public void setCourse(String Course) {
        this.Course = Course;
    }

    /**
     * @return the InstituteName
     */
    public String getInstituteName() {
        return InstituteName;
    }

    /**
     * @param InstituteName the InstituteName to set
     */
    public void setInstituteName(String InstituteName) {
        this.InstituteName = InstituteName;
    }

    /**
     * @return the Date
     */
    public String getDate() {
        return Date;
    }

    /**
     * @param Date the Date to set
     */
    public void setDate(String Date) {
        this.Date = Date;
    }
}
